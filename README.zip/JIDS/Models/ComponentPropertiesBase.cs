namespace JIDS.Models
{
    public abstract class ComponentPropertiesBase
    {
        public Guid ComponentId { get; set; }
    }
}